import React from "react";
import { Route } from "react-router-dom";
import UpdateUser from "../pages/Mypage/UpdateUser";

const mypageRouter = [
    <Route path="/mypage/:userId" element={<UpdateUser />} />
];

export default mypageRouter;
