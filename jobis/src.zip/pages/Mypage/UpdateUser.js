import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import { AuthContext } from "../../AuthProvider"; // AuthContext 가져오기

const UpdateUser = () => {
  const { userId } = useParams();
  const { secureApiRequest } = useContext(AuthContext);
  const [user, setUser] = useState({
    userId: "",
    userName: "",
    userPw: "",
    userPhone: "",
    userDefaultEmail: ""
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) {
      console.error("User ID is missing");
      setLoading(false);
      return;
    }

    const fetchUserInfo = async () => {
      setLoading(true);
      try {
        const response = await secureApiRequest(`/mypage/${userId}`);
        setUser(response.data);
      } catch (error) {
        console.error("Error loading user info:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserInfo();
  }, [userId, secureApiRequest]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prevUser => ({ ...prevUser, [name]: value }));
  };

  const handleUpdate = async () => {
    try {
      const response = await secureApiRequest(`/mypage/${userId}`, 'PUT', user);
      setUser(response.data);
      alert("User information updated successfully!");
    } catch (error) {
      console.error("Error updating user:", error);
      alert("Failed to update user information.");
    }
  };

  if (loading) return <div>Loading...</div>;
  if (!user.userId) return <div>No user data available</div>;

  return (
    <div>
      <h1>Update User</h1>
      <div>
        <label>아이디: </label>
        <input type="text" name="userId" value={user.userId} disabled readOnly />
      </div>
      <div>
        <label>이름: </label>
        <input type="text" name="userName" value={user.userName} onChange={handleChange} />
      </div>
      <div>
        <label>비밀번호:</label>
        <input type="password" name="userPw" value={user.userPw} onChange={handleChange} />
      </div>
      <div>
        <label>전화번호:</label>
        <input type="text" name="userPhone" value={user.userPhone} onChange={handleChange} />
      </div>
      <div>
        <label>이메일:</label>
        <input type="email" name="userDefaultEmail" value={user.userDefaultEmail} onChange={handleChange} />
      </div>
      <button onClick={handleUpdate}>수정 완료</button>
    </div>
  );
};

export default UpdateUser;
